#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    luku = 0;

    //connect(lähettäjänOsoite, lähettäjänSignaali,
    //         vastaanottajanOsoite, vastaanottajanSlotfunktio);

    connect(ui->Count, SIGNAL(clicked()),
            this, SLOT (countHandler()));

    connect(ui->Reset, SIGNAL(clicked()),
            this, SLOT(resetHandler()));




}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::countHandler()
{
    qDebug() << "counthandler pressed";
    luku++;
    QString num = QString::number(luku);
    ui->lineEdit->setText(num);
}

void MainWindow::resetHandler()
{
    qDebug() << "resetHandler pressed, count reset";
    luku = 0;
    QString num = QString::number(luku);
    ui->lineEdit->setText(num);
}

